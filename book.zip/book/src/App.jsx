import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { faker } from '@faker-js/faker';
import './App.css';
import BookGrid from './components/BookGrid';
import SearchBar from './components/SearchBar';
import BookDetail from './components/BookDetail';

function App() {
  const [books, setBooks] = useState([]);
  const [filteredBooks, setFilteredBooks] = useState([]);
  const [filters, setFilters] = useState({
    search: '',
    minPrice: '',
    maxPrice: '',
    genre: ''
  });

  useEffect(() => {
    const fetchBooks = async () => {
      const dummyBooks = [];
      const genres = ['Fiction', 'Non-Fiction', 'Science', 'History', 'Fantasy', 'Mystery', 'Romance', 'Biography'];
      const publishers = ['Penguin', 'Random House', 'HarperCollins', 'Simon & Schuster', 'Macmillan'];
      
      const baseBooks = [
        { title: "The Great Gatsby", author: "F. Scott Fitzgerald", id: 1, olid: "OL6749287M" },
        { title: "To Kill a Mockingbird", author: "Harper Lee", id: 2, olid: "OL7823109M" },
        { title: "1984", author: "George Orwell", id: 3, olid: "OL24382006M" },
        { title: "Pride and Prejudice", author: "Jane Austen", id: 4, olid: "OL7105876M" },
        { title: "The Hobbit", author: "J.R.R. Tolkien", id: 5, olid: "OL23374723M" }
      ];

      const fetchBookDetails = async (book) => {
        try {
          const response = await fetch(`https://openlibrary.org/api/books?bibkeys=OLID:${book.olid}&format=json&jscmd=data`);
          const data = await response.json();
          const bookData = data[`OLID:${book.olid}`];
          
          if (bookData) {
            return {
              ...book,
              price: (Math.random() * 30 + 5).toFixed(2) * 1,
              coverUrl: bookData.cover?.large || `https://covers.openlibrary.org/b/id/${book.olid}-L.jpg`,
              genre: bookData.subjects?.[0] || genres[Math.floor(Math.random() * genres.length)],
              publisher: bookData.publishers?.[0]?.name || publishers[Math.floor(Math.random() * publishers.length)],
              description: bookData.excerpts?.[0]?.text || bookData.description?.value || bookData.description || "No description available.",
              authorBio: bookData.authors?.[0]?.bio?.value || bookData.authors?.[0]?.bio || "No author information available."
            };
          }
        } catch (error) {
          console.error(`Error fetching details for ${book.title}:`, error);
        }
        
        return {
          ...book,
          price: (Math.random() * 30 + 5).toFixed(2) * 1,
          coverUrl: `https://covers.openlibrary.org/b/id/${book.olid}-L.jpg`,
          genre: genres[Math.floor(Math.random() * genres.length)],
          publisher: publishers[Math.floor(Math.random() * publishers.length)],
          description: "No description available.",
          authorBio: "No author information available."
        };
      };

      // Fetch real data for base books
      const baseBookPromises = baseBooks.map(fetchBookDetails);
      const realBooks = await Promise.all(baseBookPromises);
      dummyBooks.push(...realBooks);

      for (let i = baseBooks.length + 1; i <= 520; i++) {
        const genre = genres[Math.floor(Math.random() * genres.length)];
        const publisher = publishers[Math.floor(Math.random() * publishers.length)];
        const bookNumber = Math.floor(Math.random() * 1000);
        
        dummyBooks.push({
          id: i,
          title: `${genre} Book ${bookNumber}`,
          author: faker.person.fullName(),
          price: (Math.random() * 30 + 5).toFixed(2) * 1,
          coverUrl: `https://covers.openlibrary.org/b/id/${Math.floor(Math.random() * 10000000)}-L.jpg`,
          publisher: publisher,
          genre: genre,
          description: faker.lorem.paragraphs(3),
          authorBio: faker.lorem.paragraphs(2)
        });
      };
      setBooks(dummyBooks);
      setFilteredBooks(dummyBooks);
      window.books = dummyBooks;
    };
    fetchBooks();
  }, []);

  const handleFilterChange = (newFilters) => {
    setFilters(newFilters);
    const filtered = books.filter(book => {
      const matchesSearch = book.title.toLowerCase().includes(newFilters.search.toLowerCase()) ||
                          book.author.toLowerCase().includes(newFilters.search.toLowerCase());
      const matchesPrice = (!newFilters.minPrice || book.price >= Number(newFilters.minPrice)) &&
                          (!newFilters.maxPrice || book.price <= Number(newFilters.maxPrice));
      const matchesGenre = !newFilters.genre || book.genre === newFilters.genre;
      return matchesSearch && matchesPrice && matchesGenre;
    });
    setFilteredBooks(filtered);
  };

  return (
    <Router>
      <div className="app">
        <header className="app-header">
          <h1>Book Catalog</h1>
        </header>
        <Routes>
          <Route path="/" element={
            <main>
              <SearchBar filters={filters} onFilterChange={handleFilterChange} />
              <BookGrid books={filteredBooks} />
            </main>
          } />
          <Route path="/book/:id" element={<BookDetail />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;