import React, { useCallback } from 'react';
import debounce from 'lodash/debounce';
import './SearchBar.css';

function SearchBar({ filters, onFilterChange }) {
  const debouncedFilterChange = useCallback(
    debounce((newFilters) => {
      onFilterChange(newFilters);
    }, 300),
    []
  );

  const handleChange = (e) => {
    const { name, value } = e.target;
    const newFilters = { ...filters, [name]: value };
    debouncedFilterChange(newFilters);
  };

  return (
    <div className="search-bar">
      <input
        type="text"
        name="search"
        placeholder="Search by title or author..."
        onChange={handleChange}
        defaultValue={filters.search}
      />
      <select
        name="genre"
        onChange={handleChange}
        value={filters.genre}
        className="genre-select"
      >
        <option value="">All Genres</option>
        <option value="Fiction">Fiction</option>
        <option value="Non-Fiction">Non-Fiction</option>
        <option value="Science">Science</option>
        <option value="History">History</option>
        <option value="Fantasy">Fantasy</option>
        <option value="Mystery">Mystery</option>
        <option value="Romance">Romance</option>
        <option value="Biography">Biography</option>
      </select>
      <div className="price-filters">
        <input
          type="number"
          name="minPrice"
          placeholder="Min price"
          onChange={handleChange}
          defaultValue={filters.minPrice}
        />
        <input
          type="number"
          name="maxPrice"
          placeholder="Max price"
          onChange={handleChange}
          defaultValue={filters.maxPrice}
        />
      </div>
    </div>
  );
}

export default SearchBar;