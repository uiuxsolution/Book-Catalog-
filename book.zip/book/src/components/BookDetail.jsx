import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import './BookDetail.css';

function BookDetail() {
  const { id } = useParams();
  const [book, setBook] = useState(null);
  const [loading, setLoading] = useState(true);
  const fallbackImage = 'https://via.placeholder.com/150x200?text=No+Cover';

  useEffect(() => {
    const findBook = () => {
      if (window.books) {
        const foundBook = window.books.find(b => b.id === parseInt(id));
        setBook(foundBook);
      }
      setLoading(false);
    };

    findBook();
  }, [id]);

  if (loading) {
    return <div className="book-detail-container">Loading...</div>;
  }

  if (!book) {
    return <div className="book-detail-container">Book not found</div>;
  }

  const amazonUrl = `https://www.amazon.com/s?k=${encodeURIComponent(`${book.title} ${book.author}`)}`;

  return (
    <div className="book-detail-container">
      <div className="book-detail-content">
        <div className="book-detail-header">
          <img 
            src={book.coverUrl || fallbackImage} 
            alt={book.title} 
            className="book-detail-cover"
            onError={(e) => { e.target.src = fallbackImage }}
          />
          <div className="book-detail-info">
            <h1>{book.title}</h1>
            <h2>by {book.author}</h2>
            <p className="book-detail-genre">Genre: {book.genre}</p>
            <p className="book-detail-publisher">Publisher: {book.publisher}</p>
            <p className="book-detail-price">${book.price.toFixed(2)}</p>
            <a href={amazonUrl} target="_blank" rel="noopener noreferrer" className="amazon-link">
              View on Amazon
            </a>
          </div>
        </div>
        <div className="book-detail-description">
          <h3>About the Book</h3>
          <p>{book.description || 'No description available.'}</p>
          <h3>About the Author</h3>
          <p>{book.authorBio || 'No author information available.'}</p>
        </div>
      </div>
    </div>
  );
}

export default BookDetail;