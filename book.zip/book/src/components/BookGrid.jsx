import React from 'react';
import { Link } from 'react-router-dom';
import './BookGrid.css';

function BookGrid({ books }) {
  const fallbackImage = 'https://via.placeholder.com/150x200?text=No+Cover';

  return (
    <div className="book-grid">
      {books.map(book => (
        <Link to={`/book/${book.id}`} key={book.id} style={{ textDecoration: 'none', color: 'inherit' }}>
          <div className="book-card">
            <img
              src={book.coverUrl || fallbackImage}
              alt={book.title}
              onError={(e) => { e.target.src = fallbackImage }}
            />
            <h3>{book.title}</h3>
            <p className="author">{book.author}</p>
            <p className="price">${book.price.toFixed(2)}</p>
          </div>
        </Link>
      ))}
    </div>
  );
}

export default BookGrid;